'use strict';
const defaultMessage = 'Bonjour RUBY CLEANING SERVICES, je souhaite obtenir un devis pour vos services de nettoyage.';
document.querySelectorAll('[data-wa], [data-service]').forEach(link => {
  const message = link.dataset.service ? `Bonjour RUBY CLEANING SERVICES, je souhaite obtenir un devis pour le service : ${link.dataset.service}.` : defaultMessage;
  link.href = `https://wa.me/212668192422?text=${encodeURIComponent(message)}`;
  link.target = '_blank'; link.rel = 'noopener noreferrer';
});
const toggle = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#navigation');
function closeMenu() { navigation.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false'); toggle.setAttribute('aria-label', 'Ouvrir le menu'); }
toggle.addEventListener('click', () => { const open = navigation.classList.toggle('open'); toggle.setAttribute('aria-expanded', String(open)); toggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu'); });
navigation.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('click', event => { if (!event.target.closest('.nav-wrap')) closeMenu(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && navigation.classList.contains('open')) { closeMenu(); toggle.focus(); } });
window.matchMedia('(min-width: 851px)').addEventListener('change', event => { if (event.matches) closeMenu(); });
if ('IntersectionObserver' in window) {
  document.body.classList.add('js-ready');
  const reveals = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('shown'); reveals.unobserve(entry.target); } }), { threshold: 0.08 });
  document.querySelectorAll('.reveal').forEach(element => reveals.observe(element));
}
const navLinks = [...navigation.querySelectorAll('a[href^="#"]')];
const sections = navLinks.map(link => document.querySelector(link.getAttribute('href'))).filter(Boolean);
const backTop = document.querySelector('.back-top');
let ticking = false;
function updateScroll() {
  const current = [...sections].reverse().find(section => section.getBoundingClientRect().top <= 170) || sections[0];
  navLinks.forEach(link => { const active = link.hash === `#${current.id}`; link.classList.toggle('active', active); if (active) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current'); });
  backTop.classList.toggle('visible', window.scrollY > 650); ticking = false;
}
window.addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(updateScroll); ticking = true; } }, { passive: true });
updateScroll();
backTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' }));
const galleryItems = [...document.querySelectorAll('.gallery-item')];
const lightbox = document.querySelector('.lightbox');
let photoIndex = 0;
function showPhoto(index) { photoIndex = (index + galleryItems.length) % galleryItems.length; const item = galleryItems[photoIndex]; const image = lightbox.querySelector('img'); image.src = item.querySelector('img').src; image.alt = item.querySelector('img').alt; lightbox.querySelector('figcaption').textContent = item.dataset.caption; }
galleryItems.forEach((item, index) => item.addEventListener('click', () => { showPhoto(index); lightbox.showModal(); document.body.style.overflow = 'hidden'; }));
lightbox.querySelector('.lightbox-close').addEventListener('click', () => lightbox.close());
lightbox.querySelector('.lightbox-prev').addEventListener('click', () => showPhoto(photoIndex - 1));
lightbox.querySelector('.lightbox-next').addEventListener('click', () => showPhoto(photoIndex + 1));
lightbox.addEventListener('click', event => { if (event.target === lightbox) lightbox.close(); });
lightbox.addEventListener('close', () => { document.body.style.overflow = ''; galleryItems[photoIndex].focus(); });
lightbox.addEventListener('keydown', event => { if (event.key === 'ArrowLeft') { event.preventDefault(); showPhoto(photoIndex - 1); } if (event.key === 'ArrowRight') { event.preventDefault(); showPhoto(photoIndex + 1); } });
