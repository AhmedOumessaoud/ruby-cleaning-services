# Ruby Cleaning Services — Agadir

Landing page française, HTML5 / CSS3 / JavaScript sans framework ni étape de compilation.

## Aperçu local

Depuis ce dossier :

```powershell
python -m http.server 8080 --bind 127.0.0.1
```

Ouvrez http://127.0.0.1:8080. Le fichier index.html peut aussi être ouvert directement.

## Fonctionnalités

Navigation fixe et menu mobile, six services avec messages WhatsApp personnalisés, présentation, parcours en trois étapes, galerie avec visionneuse et navigation clavier, avantages, contact, Instagram, bouton WhatsApp flottant, retour en haut, animations respectant les préférences de mouvement réduit, navigation active, métadonnées SEO et Open Graph.

## Identité et photographies

Le logo officiel fourni est int?gr? dans le header et le footer (`assets/logo.png`). Le fichier original est conserv? sans modification ; son cadrage CSS r?duit les marges blanches pour un affichage lisible sur mobile et ordinateur.

Les photographies générées sont des illustrations des métiers et non des preuves de réalisations ou des portraits de l’équipe réelle. Voir `assets/prompts.json` pour les consignes de génération. Aucun témoignage, certification, résultat chiffré ou promesse environnementale n’est inventé.

## Mise en ligne

Publier le contenu de ce dossier sur un hébergement statique HTTPS. Configurer les champs `og:image` et, si souhaité, `og:url` avec les URL absolues du domaine final. Le site ne collecte aucune donnée et n’utilise ni cookies de suivi ni dépendances externes. Les liens WhatsApp transmettent le message prérempli uniquement à l’ouverture de WhatsApp ; le visiteur choisit ensuite de l’envoyer.

Téléphone : +212668192422. Instagram : rubycleaning_groupe_agadir.
